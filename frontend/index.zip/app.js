const form = document.querySelector('#search-form');
const statusEl = document.querySelector('#status');
const clearButton = document.querySelector('#clear-button');
const advancedSearchToggle = document.querySelector('#advanced-search-toggle');
const advancedSearchPanel = document.querySelector('#advanced-search-panel');
const simpleSearchLabels = document.querySelectorAll('.simple-search-row label');
const clearSelectionButton = document.querySelector('#clear-selection-button');
const selectionCountEl = document.querySelector('#selection-count');
const selectPageCheckbox = document.querySelector('#select-page');
const selectDataTableCheckbox = document.querySelector('#select-datatable');
const leadPanelSummary = document.querySelector('#lead-panel-summary');
const selectedLeadsEl = document.querySelector('#selected-leads');
const queryFilter = document.querySelector('#query-filter');
const cnpjFilter = document.querySelector('#cnpj-filter');
const razaoFilter = document.querySelector('#razao-filter');
const fantasiaFilter = document.querySelector('#fantasia-filter');
const ufSelect = document.querySelector('#uf');
const municipioInput = document.querySelector('#municipio');
const cnaeInput = document.querySelector('#cnae');
const cnaesList = document.querySelector('#cnaes-list');
const aberturaInicioInput = document.querySelector('#abertura-inicio');
const aberturaFimInput = document.querySelector('#abertura-fim');
const tableWrap = document.querySelector('.table-wrap');
const notesPanel = document.querySelector('.notes-panel');
const tableShowSummary = document.querySelector('#table-show-summary');
const notesTitle = document.querySelector('#notes-title');
const companySnapshot = document.querySelector('#company-snapshot');
const prospectionForm = document.querySelector('#prospection-form');
const prospectionNotes = document.querySelector('#prospection-notes');
const prospectionEditor = document.querySelector('#prospection-editor');
const prospectionStatus = document.querySelector('#prospection-status');
const saveProspectionButton = document.querySelector('#save-prospection-button');
const backToTableButton = document.querySelector('#back-to-table-button');
const contactPersonInput = document.querySelector('#contact-person');
const contactRoleInput = document.querySelector('#contact-role');
const nextContactInput = document.querySelector('#next-contact');
const employeeCountInput = document.querySelector('#employee-count');
const benefitsInput = document.querySelector('#benefits');
const contactHistoryEl = document.querySelector('#contact-history');
const nextContactField = document.querySelector('.next-contact-field');
const historyTitle = document.querySelector('.history-column > strong');
let municipalityRequestId = 0;
let cnaeRequestId = 0;
let resultsTable;
let hasSearched = false;
let currentCompany = null;
let currentProspectionState = { draftHtml: '', history: [] };
const selectedCompanies = new Set();
const selectedLeadDrafts = new Map();

if (nextContactField?.firstChild) {
    nextContactField.firstChild.textContent = 'Próximo contato';
}

if (historyTitle) {
    historyTitle.textContent = 'Histórico de Contatos';
}

if (simpleSearchLabels.length >= 3) {
    simpleSearchLabels[0].childNodes[0].textContent = 'Razão Social';
    simpleSearchLabels[1].childNodes[0].textContent = 'CNPJ';
    simpleSearchLabels[2].childNodes[0].textContent = 'Nome Fantasia';
}

const dataTableColumnMap = {
    5: 4,
    8: 8
};

function escapeHtml(value) {
    return String(value ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

function formatCnpj(value) {
    const digits = String(value || '');

    if (digits.length !== 14) {
        return escapeHtml(value || '');
    }

    return `${digits.slice(0, 2)}.${digits.slice(2, 5)}.${digits.slice(5, 8)}/${digits.slice(8, 12)}-${digits.slice(12)}`;
}

function formatTelefone(item) {
    const ddd1 = item.DDD_1 ? `(${item.DDD_1}) ` : '';
    const telefone1 = item.TELEFONE_1 || '';
    const ddd2 = item.DDD_2 ? `(${item.DDD_2}) ` : '';
    const telefone2 = item.TELEFONE_2 || '';
    const principal = `${ddd1}${telefone1}`.trim();
    const secundario = `${ddd2}${telefone2}`.trim();

    if (principal && secundario) {
        return `${escapeHtml(principal)}<span>${escapeHtml(secundario)}</span>`;
    }

    return escapeHtml(principal || secundario || '-');
}

function getPhoneText(item) {
    const ddd1 = item.DDD_1 ? `(${item.DDD_1}) ` : '';
    const telefone1 = item.TELEFONE_1 || '';
    const ddd2 = item.DDD_2 ? `(${item.DDD_2}) ` : '';
    const telefone2 = item.TELEFONE_2 || '';

    return `${ddd1}${telefone1}`.trim() || `${ddd2}${telefone2}`.trim();
}

function formatDate(value) {
    const digits = String(value || '');

    if (digits.length !== 8) {
        return escapeHtml(valueOrDash(value));
    }

    return `${digits.slice(6, 8)}/${digits.slice(4, 6)}/${digits.slice(0, 4)}`;
}

function valueOrDash(value) {
    return value === null || value === undefined || value === '' ? '-' : value;
}

function truncateCell(value, className = '') {
    const text = valueOrDash(value);
    const escaped = escapeHtml(text);

    return `<span class="cell-truncate ${className}" title="${escaped}">${escaped}</span>`;
}

function renderFlagButton(item) {
    const isFlagged = Number(item?.FLAG_ATIVA || 0) === 1;
    const title = isFlagged ? 'Remover flag da empresa' : 'Marcar empresa com flag';

    return `
        <button
            class="company-flag-button${isFlagged ? ' is-flagged' : ''}"
            type="button"
            data-cnpj="${escapeHtml(item?.CNPJ || '')}"
            aria-pressed="${isFlagged ? 'true' : 'false'}"
            title="${title}"
        >
            <span aria-hidden="true"></span>
            <span class="visually-hidden">${title}</span>
        </button>
    `;
}

function maskDate(value) {
    const digits = String(value || '').replace(/\D/g, '').slice(0, 8);

    if (digits.length <= 2) {
        return digits;
    }

    if (digits.length <= 4) {
        return `${digits.slice(0, 2)}/${digits.slice(2)}`;
    }

    return `${digits.slice(0, 2)}/${digits.slice(2, 4)}/${digits.slice(4)}`;
}

function toDatabaseDate(value) {
    const digits = String(value || '').replace(/\D/g, '');

    if (digits.length !== 8) {
        return '';
    }

    return `${digits.slice(4, 8)}${digits.slice(2, 4)}${digits.slice(0, 2)}`;
}

function syncQueryFilter() {
    if (!queryFilter) {
        return;
    }

    queryFilter.value = cnpjFilter.value.trim()
        || razaoFilter.value.trim()
        || fantasiaFilter.value.trim();
}

function appendFormFilters(params) {
    syncQueryFilter();
    const data = new FormData(form);

    for (const [key, value] of data.entries()) {
        let normalizedValue = String(value).trim();

        if (key === 'aberturaInicio' || key === 'aberturaFim') {
            normalizedValue = toDatabaseDate(normalizedValue);
        }

        if (normalizedValue !== '') {
            params.set(key, normalizedValue);
        }
    }
}

function syncSwitchConflicts(input) {
    const conflicts = input.dataset.conflicts;

    if (!input.checked || !conflicts) {
        return;
    }

    for (const id of conflicts.split(',')) {
        const conflictingInput = document.getElementById(id.trim());

        if (conflictingInput) {
            conflictingInput.checked = false;
        }
    }
}

function buildDataTableParams(data) {
    const params = new URLSearchParams();
    const order = data.order?.[0];

    params.set('draw', data.draw ?? 0);
    params.set('start', data.start ?? 0);
    params.set('length', data.length ?? 25);

    if (order && dataTableColumnMap[order.column] !== undefined) {
        params.set('order[0][column]', dataTableColumnMap[order.column]);
        params.set('order[0][dir]', order.dir || 'asc');
    }

    if (data.search?.value) {
        params.set('search[value]', data.search.value);
    }

    appendFormFilters(params);

    return params;
}

function updateMunicipioAvailability() {
    const hasUf = Boolean(ufSelect?.value);

    if (municipioInput) {
        municipioInput.disabled = !hasUf;

        if (!hasUf) {
            municipioInput.innerHTML = '<option value="">Selecione a UF</option>';
        }
    }
}

function updateSelectionCount() {
    const total = selectedCompanies.size;
    selectionCountEl.textContent = `${total.toLocaleString('pt-BR')} selecionada${total === 1 ? '' : 's'}`;

    if (leadPanelSummary) {
        leadPanelSummary.textContent = total === 0
            ? 'Nenhuma empresa selecionada'
            : `${total.toLocaleString('pt-BR')} empresa${total === 1 ? '' : 's'} no rascunho`;
    }
}

function createLeadDraft(item) {
    return {
        cnpj: item.CNPJ,
        razaoSocial: item.RAZAO_SOCIAL || '',
        telefone: getPhoneText(item),
        contato: '',
        email: '',
        observacoes: ''
    };
}

function buildCompanySnapshot(item) {
    if (!item) {
        return '';
    }

    return [
        `CNPJ: ${formatCnpj(item.CNPJ).replace(/<[^>]+>/g, '')}`,
        `Razão Social: ${valueOrDash(item.RAZAO_SOCIAL)}`,
        `Nome Fantasia: ${valueOrDash(item.NOME_FANTASIA)}`,
        `Município/UF: ${valueOrDash(item.MUNICIPIO_DESCRICAO)} / ${valueOrDash(item.UF)}`,
        `Telefone: ${valueOrDash(getPhoneText(item))}`,
        `CNAE: ${valueOrDash(item.CNAE_FISCAL_PRINCIPAL)} - ${valueOrDash(item.CNAE_FISCAL_PRINCIPAL_DESCRICAO)}`,
        `Abertura: ${formatDate(item.DATA_INICIO_ATIVIDADE)}`,
        `Porte: ${valueOrDash(item.PORTE_EMPRESA)}`
    ].join('\n');
}

function buildCompanySnapshotHtml(item) {
    if (!item) {
        return '';
    }

    const rows = [
        ['CNPJ', formatCnpj(item.CNPJ).replace(/<[^>]+>/g, '')],
        ['Razão Social', valueOrDash(item.RAZAO_SOCIAL)],
        ['Nome Fantasia', valueOrDash(item.NOME_FANTASIA)],
        ['Município/UF', `${valueOrDash(item.MUNICIPIO_DESCRICAO)} / ${valueOrDash(item.UF)}`],
        ['Telefone', valueOrDash(getPhoneText(item))],
        ['CNAE', `${valueOrDash(item.CNAE_FISCAL_PRINCIPAL)} - ${valueOrDash(item.CNAE_FISCAL_PRINCIPAL_DESCRICAO)}`],
        ['Abertura', formatDate(item.DATA_INICIO_ATIVIDADE)],
        ['Porte', valueOrDash(item.PORTE_EMPRESA)]
    ];

    return `
        <div class="notepad-company">
            ${rows.map(([label, value]) => `
                <p><strong>${escapeHtml(label)}:</strong> ${escapeHtml(value)}</p>
            `).join('')}
        </div>
        <div class="notepad-divider"></div>
        <p><strong>Observações do contato:</strong></p>
        <p><br></p>
    `;
}

function formatStoredProspectionNotes(value) {
    const content = String(value || '').trim();

    if (!content) {
        return '';
    }

    if (/<[a-z][\s\S]*>/i.test(content)) {
        return content;
    }

    return escapeHtml(content).replace(/\n/g, '<br>');
}

function parseProspectionState(rawValue, item) {
    const content = String(rawValue || '').trim();
    const fallbackDraft = buildCompanySnapshotHtml(item);

    if (!content) {
        return {
            draftHtml: fallbackDraft,
            history: []
        };
    }

    try {
        const parsed = JSON.parse(content);

        if (parsed && parsed.kind === 'leadbenefits-contact-history') {
            return {
                draftHtml: parsed.draftHtml || fallbackDraft,
                history: Array.isArray(parsed.history) ? parsed.history : []
            };
        }
    } catch {
        // Conteudos antigos eram salvos como HTML/texto simples.
    }

    const storedNotes = formatStoredProspectionNotes(content);

    return {
        draftHtml: storedNotes && storedNotes.includes('notepad-company')
            ? storedNotes
            : `${fallbackDraft}${storedNotes ? `<div class="notepad-divider"></div>${storedNotes}` : ''}`,
        history: []
    };
}

function serializeProspectionState(state) {
    return JSON.stringify({
        kind: 'leadbenefits-contact-history',
        draftHtml: state.draftHtml || '',
        history: Array.isArray(state.history) ? state.history : []
    });
}

function formatHistoryDate(value) {
    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return valueOrDash(value);
    }

    return date.toLocaleString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function formatIsoDate(value) {
    const rawValue = String(value || '').trim();

    if (!/^\d{4}-\d{2}-\d{2}$/.test(rawValue)) {
        return valueOrDash(rawValue);
    }

    const [year, month, day] = rawValue.split('-');
    return `${day}/${month}/${year}`;
}

function renderContactHistory(history = []) {
    if (!contactHistoryEl) {
        return;
    }

    if (!history.length) {
        contactHistoryEl.innerHTML = '<p class="empty-history">Nenhum contato registrado.</p>';
        return;
    }

    contactHistoryEl.innerHTML = history
        .slice()
        .reverse()
        .map((entry) => `
            <article class="history-entry">
                <p><strong>Data/hora:</strong> ${escapeHtml(formatHistoryDate(entry.at))}</p>
                <p><strong>Quem atendeu:</strong> ${escapeHtml(valueOrDash(entry.contactPerson))}</p>
                <p><strong>Cargo:</strong> ${escapeHtml(valueOrDash(entry.contactRole))}</p>
                <p><strong>Número de funcionários:</strong> ${escapeHtml(valueOrDash(entry.employeeCount))}</p>
                <p><strong>Benefícios:</strong> ${escapeHtml(valueOrDash(entry.benefits))}</p>
                <p><strong>Próximo contato:</strong> ${escapeHtml(formatIsoDate(entry.nextContact))}</p>
                <p><strong>Informações do contato:</strong></p>
                <div class="history-entry-notes">${entry.notesHtml || ''}</div>
            </article>
        `)
        .join('');
}

function showProspectionPanel() {
    tableWrap?.classList.add('is-hidden');
    notesPanel?.classList.remove('is-hidden');
}

function showResultsTable() {
    notesPanel?.classList.add('is-hidden');
    tableWrap?.classList.remove('is-hidden');
}

function syncProspectionEditor() {
    if (prospectionEditor && prospectionNotes) {
        currentProspectionState.draftHtml = prospectionEditor.innerHTML;
        prospectionNotes.value = serializeProspectionState(currentProspectionState);
    }
}

function setProspectionStatus(message) {
    if (prospectionStatus) {
        prospectionStatus.textContent = message;
    }
}

async function loadProspection(cnpj) {
    const response = await fetch(`/api/prospeccoes?cnpj=${encodeURIComponent(cnpj)}`);
    const payload = await response.json();

    if (!response.ok) {
        throw new Error(payload.error || 'Erro ao carregar histórico.');
    }

    return payload.prospeccao;
}

async function saveCompanyFlag(cnpj, ativa) {
    const response = await fetch('/api/empresas/flag', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ cnpj, ativa })
    });
    const payload = await response.json();

    if (!response.ok) {
        throw new Error(payload.error || 'Erro ao atualizar flag.');
    }

    return payload.flagAtiva;
}

function renderCompanyNotes(item, prospeccao = null) {
    currentCompany = item;

    if (!item) {
        notesTitle.textContent = 'Selecione uma empresa';
        if (companySnapshot) {
            companySnapshot.value = '';
        }
        prospectionNotes.value = '';
        if (prospectionEditor) {
            prospectionEditor.innerHTML = '';
        }
        if (contactPersonInput) {
            contactPersonInput.value = '';
        }
        if (contactRoleInput) {
            contactRoleInput.value = '';
        }
        if (nextContactInput) {
            nextContactInput.value = '';
        }
        if (employeeCountInput) {
            employeeCountInput.value = '';
        }
        if (benefitsInput) {
            benefitsInput.value = '';
        }
        currentProspectionState = { draftHtml: '', history: [] };
        renderContactHistory([]);
        saveProspectionButton.disabled = true;
        setProspectionStatus('Nenhuma empresa selecionada');
        showResultsTable();
        return;
    }

    notesTitle.textContent = `${valueOrDash(item.RAZAO_SOCIAL)} - ${formatCnpj(item.CNPJ)}`;
    if (companySnapshot) {
        companySnapshot.value = buildCompanySnapshot(item);
    }

    currentProspectionState = parseProspectionState(prospeccao?.observacoes, item);

    prospectionNotes.value = serializeProspectionState(currentProspectionState);
    if (prospectionEditor) {
        prospectionEditor.innerHTML = currentProspectionState.draftHtml;
    }
    if (contactPersonInput) {
        contactPersonInput.value = '';
    }
    if (contactRoleInput) {
        contactRoleInput.value = '';
    }
    if (nextContactInput) {
        nextContactInput.value = prospeccao?.proximoContato || '';
    }
    if (employeeCountInput) {
        employeeCountInput.value = prospeccao?.numeroFuncionarios || '';
    }
    if (benefitsInput) {
        benefitsInput.value = prospeccao?.beneficios || '';
    }
    renderContactHistory(currentProspectionState.history);
    saveProspectionButton.disabled = false;
    showProspectionPanel();
    setProspectionStatus(prospeccao?.atualizadoEm ? `Histórico carregado: ${prospeccao.atualizadoEm}` : 'Pronto para registrar contato');
}

async function selectCompanyForNotes(item) {
    if (!item?.CNPJ) {
        return;
    }

    renderCompanyNotes(item);
    setProspectionStatus('Carregando histórico...');

    try {
        const prospeccao = await loadProspection(item.CNPJ);
        renderCompanyNotes(item, prospeccao);
    } catch (error) {
        setProspectionStatus(error.message);
    }
}

function addSelectedCompany(item) {
    if (!item?.CNPJ) {
        return;
    }

    selectedCompanies.add(item.CNPJ);

    if (!selectedLeadDrafts.has(item.CNPJ)) {
        selectedLeadDrafts.set(item.CNPJ, createLeadDraft(item));
    }
}

function removeSelectedCompany(cnpj) {
    selectedCompanies.delete(cnpj);
    selectedLeadDrafts.delete(cnpj);
}

function renderSelectedLeads() {
    if (!selectedLeadsEl) {
        return;
    }

    if (selectedLeadDrafts.size === 0) {
        selectedLeadsEl.innerHTML = '<div class="empty-selection">Selecione empresas na tabela para preparar contatos.</div>';
        return;
    }

    selectedLeadsEl.innerHTML = '';

    for (const lead of selectedLeadDrafts.values()) {
        const card = document.createElement('article');
        card.className = 'lead-card';
        card.dataset.cnpj = lead.cnpj;
        card.innerHTML = `
            <div class="lead-card-title">
                <strong>${escapeHtml(valueOrDash(lead.razaoSocial))}</strong>
                <button class="remove-lead-button" type="button" aria-label="Remover ${formatCnpj(lead.cnpj)}">Remover</button>
            </div>
            <label>
                CNPJ
                <input value="${formatCnpj(lead.cnpj)}" readonly>
            </label>
            <label>
                Razão Social
                <input value="${escapeHtml(lead.razaoSocial)}" readonly>
            </label>
            <label>
                Telefone
                <input data-field="telefone" value="${escapeHtml(lead.telefone)}">
            </label>
            <label>
                Nome do contato
                <input data-field="contato" value="${escapeHtml(lead.contato)}">
            </label>
            <label>
                E-mail
                <input data-field="email" type="email" value="${escapeHtml(lead.email)}">
            </label>
            <label>
                Observações
                <textarea data-field="observacoes" rows="3">${escapeHtml(lead.observacoes)}</textarea>
            </label>
        `;
        selectedLeadsEl.appendChild(card);
    }
}

function getCurrentPageCnpjs() {
    if (!resultsTable) {
        return [];
    }

    return resultsTable
        .rows({ page: 'current' })
        .data()
        .toArray()
        .map((item) => item.CNPJ)
        .filter(Boolean);
}

function syncPageSelectionState() {
    const currentCnpjs = getCurrentPageCnpjs();
    const selectedOnPage = currentCnpjs.filter((cnpj) => selectedCompanies.has(cnpj));

    document.querySelectorAll('.row-select').forEach((checkbox) => {
        checkbox.checked = selectedCompanies.has(checkbox.dataset.cnpj);
    });

    if (!selectPageCheckbox) {
        return;
    }

    selectPageCheckbox.checked = currentCnpjs.length > 0 && selectedOnPage.length === currentCnpjs.length;
    selectPageCheckbox.indeterminate = selectedOnPage.length > 0 && selectedOnPage.length < currentCnpjs.length;

    if (selectDataTableCheckbox) {
        selectDataTableCheckbox.checked = selectPageCheckbox.checked;
        selectDataTableCheckbox.indeterminate = selectPageCheckbox.indeterminate;
    }
}

function selectCurrentDataTablePage() {
    const currentRows = resultsTable.rows({ page: 'current' }).data().toArray();

    for (const row of currentRows) {
        addSelectedCompany(row);
    }
}

function clearAllSelections() {
    selectedCompanies.clear();
    selectedLeadDrafts.clear();
    syncPageSelectionState();
    updateSelectionCount();
    renderSelectedLeads();
}

async function loadMunicipios(uf, searchTerm = '') {
    if (!uf || !municipioInput) {
        if (municipioInput) {
            municipioInput.innerHTML = '<option value="">Selecione a UF</option>';
        }
        return;
    }

    const currentRequestId = ++municipalityRequestId;
    const query = new URLSearchParams({ uf, q: searchTerm.trim() }).toString();
    const response = await fetch(`/api/municipios?${query}`);

    if (!response.ok) {
        return;
    }

    const data = await response.json();

    if (currentRequestId !== municipalityRequestId) {
        return;
    }

    municipioInput.innerHTML = '<option value="">Todos</option>';

    for (const item of data) {
        const option = document.createElement('option');
        option.value = item.codigo;
        option.textContent = item.nome;
        municipioInput.appendChild(option);
    }
}

async function loadCnaes(searchTerm = '') {
    const term = searchTerm.trim();

    if (!cnaesList) {
        return;
    }

    if (term.length < 2) {
        cnaesList.innerHTML = '';
        return;
    }

    const currentRequestId = ++cnaeRequestId;
    const response = await fetch(`/api/cnaes?q=${encodeURIComponent(term)}`);

    if (!response.ok) {
        return;
    }

    const data = await response.json();

    if (currentRequestId !== cnaeRequestId) {
        return;
    }

    cnaesList.innerHTML = '';

    for (const item of data) {
        const option = document.createElement('option');
        option.value = item.label;
        cnaesList.appendChild(option);
    }
}

function initializeDataTable() {
    resultsTable = new DataTable('#results-table', {
        serverSide: true,
        processing: true,
        searching: true,
        ajax: async (data, callback) => {
            if (!hasSearched) {
                callback({
                    draw: data.draw,
                    recordsTotal: 0,
                    recordsFiltered: 0,
                    data: []
                });
                return;
            }

            statusEl.textContent = 'Pesquisando...';

            try {
                const response = await fetch(`/api/empresas?${buildDataTableParams(data).toString()}`);
                const payload = await response.json();

                if (!response.ok) {
                    throw new Error(payload.error || 'Erro ao pesquisar.');
                }

                const totalLabel = payload.hasMore
                    ? `mais de ${payload.recordsFiltered.toLocaleString('pt-BR')}`
                    : payload.recordsFiltered.toLocaleString('pt-BR');
                statusEl.textContent = `${totalLabel} resultados em ${payload.elapsedMs} ms`;
                callback(payload);
            } catch (error) {
                statusEl.textContent = error.message;
                callback({
                    draw: data.draw,
                    recordsTotal: 0,
                    recordsFiltered: 0,
                    data: []
                });
            }
        },
        columns: [
            {
                data: 'CNPJ',
                orderable: false,
                searchable: false,
                className: 'select-cell',
                render: (value) => `
                    <input class="row-select" type="checkbox" data-cnpj="${escapeHtml(value)}" aria-label="Selecionar empresa ${formatCnpj(value)}">
                `
            },
            {
                data: null,
                orderable: false,
                searchable: false,
                className: 'flag-cell',
                render: (item) => renderFlagButton(item)
            },
            {
                data: 'RAZAO_SOCIAL',
                orderable: false,
                render: (value) => `<strong>${truncateCell(value)}</strong>`
            },
            {
                data: 'NOME_FANTASIA',
                orderable: false,
                render: (value) => truncateCell(value)
            },
            {
                data: 'MUNICIPIO_DESCRICAO',
                orderable: false,
                render: (value) => truncateCell(value)
            },
            {
                data: 'UF',
                orderable: true,
                render: (value) => escapeHtml(valueOrDash(value))
            },
            {
                data: null,
                orderable: false,
                render: (item) => formatTelefone(item)
            },
            {
                data: 'CNAE_FISCAL_PRINCIPAL',
                orderable: false,
                render: (value, type, item) => {
                    const code = valueOrDash(value);
                    const description = valueOrDash(item.CNAE_FISCAL_PRINCIPAL_DESCRICAO);
                    const title = escapeHtml(`${code} - ${description}`);

                    return `
                        <strong class="cell-truncate" title="${title}">${escapeHtml(code)}</strong>
                        <span class="cell-truncate" title="${title}">${escapeHtml(description)}</span>
                    `;
                }
            },
            {
                data: 'DATA_INICIO_ATIVIDADE',
                orderable: true,
                render: (value) => formatDate(value)
            },
            {
                data: 'PORTE_EMPRESA',
                orderable: false,
                render: (value) => truncateCell(value)
            },
            {
                data: 'CNPJ',
                orderable: false,
                render: (value) => formatCnpj(value)
            }
        ],
        pageLength: 25,
        lengthMenu: [10, 25, 50, 100, 200],
        lengthChange: false,
        order: [],
        drawCallback: () => {
            syncPageSelectionState();
            updateSelectionCount();
            renderSelectedLeads();

            if (tableShowSummary) {
                const pageLength = resultsTable?.page.len?.() || 25;
                tableShowSummary.textContent = `Mostrar ${pageLength} registros por página. Use a paginação para navegar pelos resultados.`;
            }
        },
        language: {
            decimal: ',',
            thousands: '.',
            emptyTable: 'Nenhum resultado encontrado.',
            info: 'Mostrando _START_ até _END_ de _TOTAL_ registros conhecidos',
            infoEmpty: 'Mostrando 0 até 0 de 0 registros',
            infoFiltered: '(filtrado de _MAX_ registros no total)',
            lengthMenu: 'Mostrar _MENU_ registros por página',
            loadingRecords: 'Carregando...',
            processing: 'Processando...',
            search: 'Buscar na tabela:',
            zeroRecords: 'Nenhum registro correspondente encontrado',
            paginate: {
                first: 'Primeiro',
                last: 'Último',
                next: 'Próximo',
                previous: 'Anterior'
            },
            aria: {
                orderable: 'Ordenar por esta coluna',
                orderableReverse: 'Inverter ordenação desta coluna'
            }
        }
    });
}

function search(event) {
    event.preventDefault();
    hasSearched = true;

    closeAdvancedSearch();
    showResultsTable();
    resultsTable.ajax.reload();
}

form.addEventListener('submit', search);

function closeAdvancedSearch() {
    if (!advancedSearchToggle || !advancedSearchPanel) {
        return;
    }

    advancedSearchPanel.hidden = true;
    advancedSearchToggle.setAttribute('aria-expanded', 'false');
    advancedSearchToggle.classList.remove('is-active');
}

if (advancedSearchToggle && advancedSearchPanel) {
    advancedSearchToggle.addEventListener('click', () => {
        const willOpen = advancedSearchPanel.hidden;

        advancedSearchPanel.hidden = !willOpen;
        advancedSearchToggle.setAttribute('aria-expanded', String(willOpen));
        advancedSearchToggle.classList.toggle('is-active', willOpen);
    });
}

if (backToTableButton) {
    backToTableButton.addEventListener('click', showResultsTable);
}

if (prospectionEditor) {
    prospectionEditor.addEventListener('input', syncProspectionEditor);
}

for (const input of [cnpjFilter, razaoFilter, fantasiaFilter]) {
    input.addEventListener('input', syncQueryFilter);
}

document.querySelectorAll('.switch-filter input').forEach((input) => {
    input.addEventListener('change', () => syncSwitchConflicts(input));
});

if (ufSelect) {
    ufSelect.addEventListener('change', () => {
        updateMunicipioAvailability();
        loadMunicipios(ufSelect.value, '');
    });
}

if (cnaeInput) {
    cnaeInput.addEventListener('focus', () => loadCnaes(cnaeInput.value));
    cnaeInput.addEventListener('input', () => loadCnaes(cnaeInput.value));
}

for (const dateInput of [aberturaInicioInput, aberturaFimInput]) {
    if (dateInput) {
        dateInput.addEventListener('input', () => {
            dateInput.value = maskDate(dateInput.value);
        });
    }
}

document.querySelector('#results-table').addEventListener('change', (event) => {
    if (!event.target.classList.contains('row-select')) {
        return;
    }

    const cnpj = event.target.dataset.cnpj;

    if (!cnpj) {
        return;
    }

    if (event.target.checked) {
        const rowData = resultsTable
            .rows({ page: 'current' })
            .data()
            .toArray()
            .find((item) => item.CNPJ === cnpj);
        addSelectedCompany(rowData);
    } else {
        removeSelectedCompany(cnpj);
    }

    syncPageSelectionState();
    updateSelectionCount();
    renderSelectedLeads();
});

document.querySelector('#results-table').addEventListener('click', async (event) => {
    const button = event.target.closest('.company-flag-button');

    if (!button) {
        return;
    }

    event.preventDefault();
    event.stopPropagation();

    const row = button.closest('tr');
    const rowData = resultsTable?.row(row).data();
    const cnpj = button.dataset.cnpj;

    if (!rowData || !cnpj) {
        return;
    }

    const nextFlagState = Number(rowData.FLAG_ATIVA || 0) !== 1;
    button.disabled = true;

    try {
        const flagAtiva = await saveCompanyFlag(cnpj, nextFlagState);
        rowData.FLAG_ATIVA = flagAtiva ? 1 : 0;
        resultsTable.row(row).data(rowData).invalidate();
        syncPageSelectionState();
    } catch (error) {
        statusEl.textContent = error.message;
    } finally {
        button.disabled = false;
    }
});

document.querySelector('#results-table tbody').addEventListener('click', (event) => {
    if (event.target.closest('input, button, a')) {
        return;
    }

    const row = event.target.closest('tr');

    if (!row || !resultsTable) {
        return;
    }

    const rowData = resultsTable.row(row).data();

    if (!rowData) {
        return;
    }

    document.querySelectorAll('#results-table tbody tr').forEach((tableRow) => {
        tableRow.classList.remove('selected-row');
    });
    row.classList.add('selected-row');
    selectCompanyForNotes(rowData);
});

selectPageCheckbox.addEventListener('change', () => {
    const currentRows = resultsTable.rows({ page: 'current' }).data().toArray();

    for (const row of currentRows) {
        if (selectPageCheckbox.checked) {
            addSelectedCompany(row);
        } else {
            removeSelectedCompany(row.CNPJ);
        }
    }

    syncPageSelectionState();
    updateSelectionCount();
    renderSelectedLeads();
});

selectDataTableCheckbox.addEventListener('change', () => {
    if (selectDataTableCheckbox.checked) {
        selectCurrentDataTablePage();
    } else {
        clearAllSelections();
        return;
    }

    syncPageSelectionState();
    updateSelectionCount();
    renderSelectedLeads();
});

clearSelectionButton.addEventListener('click', () => {
    clearAllSelections();
});

selectedLeadsEl.addEventListener('input', (event) => {
    const field = event.target.dataset.field;
    const card = event.target.closest('.lead-card');

    if (!field || !card) {
        return;
    }

    const draft = selectedLeadDrafts.get(card.dataset.cnpj);

    if (draft) {
        draft[field] = event.target.value;
    }
});

selectedLeadsEl.addEventListener('click', (event) => {
    if (!event.target.classList.contains('remove-lead-button')) {
        return;
    }

    const card = event.target.closest('.lead-card');

    if (!card) {
        return;
    }

    removeSelectedCompany(card.dataset.cnpj);
    syncPageSelectionState();
    updateSelectionCount();
    renderSelectedLeads();
});

clearButton.addEventListener('click', () => {
    form.reset();
    cnpjFilter.value = '';
    razaoFilter.value = '';
    fantasiaFilter.value = '';
    syncQueryFilter();
    hasSearched = false;
    statusEl.textContent = 'Pronto para pesquisar';
    updateMunicipioAvailability();
    cnaesList.innerHTML = '';
    currentCompany = null;
    renderCompanyNotes(null);
    resultsTable.search('');
    resultsTable.clear().draw();
});

prospectionForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    syncProspectionEditor();

    if (!currentCompany?.CNPJ) {
        return;
    }

    const nextProspectionState = {
        draftHtml: currentProspectionState.draftHtml,
        history: [
            ...(currentProspectionState.history || []),
            {
                at: new Date().toISOString(),
                contactPerson: contactPersonInput?.value.trim() || '-',
                contactRole: contactRoleInput?.value.trim() || '-',
                nextContact: nextContactInput?.value || '',
                employeeCount: employeeCountInput?.value || '',
                benefits: benefitsInput?.value.trim() || '',
                notesHtml: currentProspectionState.draftHtml
            }
        ]
    };
    const serializedProspection = serializeProspectionState(nextProspectionState);

    saveProspectionButton.disabled = true;
    setProspectionStatus('Salvando histórico...');

    try {
        const response = await fetch(`/api/prospeccoes?cnpj=${encodeURIComponent(currentCompany.CNPJ)}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                dadosEmpresa: currentCompany,
                observacoes: serializedProspection,
                nomeContato: contactPersonInput?.value.trim() || '',
                cargoContato: contactRoleInput?.value.trim() || '',
                proximoContato: nextContactInput?.value || '',
                numeroFuncionarios: employeeCountInput?.value || '',
                beneficios: benefitsInput?.value.trim() || ''
            })
        });
        const payload = await response.json();

        if (!response.ok) {
            throw new Error(payload.error || 'Erro ao salvar histórico.');
        }

        currentProspectionState = parseProspectionState(payload.prospeccao?.observacoes, currentCompany);
        prospectionNotes.value = serializeProspectionState(currentProspectionState);
        renderContactHistory(currentProspectionState.history);
        if (contactPersonInput) {
            contactPersonInput.value = '';
        }
        if (contactRoleInput) {
            contactRoleInput.value = '';
        }
        if (nextContactInput) {
            nextContactInput.value = payload.prospeccao?.proximoContato || '';
        }
        if (employeeCountInput) {
            employeeCountInput.value = payload.prospeccao?.numeroFuncionarios || '';
        }
        if (benefitsInput) {
            benefitsInput.value = '';
        }
        setProspectionStatus(`Histórico salvo: ${payload.prospeccao.atualizadoEm}`);
    } catch (error) {
        setProspectionStatus(error.message);
    } finally {
        saveProspectionButton.disabled = false;
    }
});

initializeDataTable();
updateMunicipioAvailability();
updateSelectionCount();
renderSelectedLeads();
renderCompanyNotes(null);
